#!/bin/bash
user=`logname`
home="/home/$user"
if [ ! `whoami` == root ]; then
	echo "This script must be run with sudo."
	exit 1
fi
if [ -z "$1" ]; then
        echo "ssh_logs.sh ls|get filename"
        exit 1
else
        if [[ "$1" == "get" ]] && [[ -z "$2" ]]; then
                echo "ssh_logs.sh ls|get filename"
                exit 1
        fi
fi
case "$1" in
        ls)
                ls /var/log/sft/sessions
                exit 0
        ;;
        get)
                cp /var/log/sft/sessions/$2 $home
                chown $user $home/$2
                echo "Copied the following file from /var/log/sft/sessions to your home directory."
                echo "$2"
        ;;
esac
