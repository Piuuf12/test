#!/bin/bash
#Check for already running
ps -ef | grep -v grep | grep sft-gatewayd > /dev/null
if [ $? -eq 0 ]
then
	echo "ASA Gateway already running"
else
        echo "Adding the Advanced Server Access repository key"
        curl -fsSL https://dist.scaleft.com/GPG-KEY-OktaPAM-2023 | gpg --dearmor | sudo tee /usr/share/keyrings/oktapam-2023-archive-keyring.gpg > /dev/null
        echo "Create a package resource list entry"
        echo "deb [signed-by=/usr/share/keyrings/oktapam-2023-archive-keyring.gpg] https://dist.scaleft.com/repos/deb focal okta" | sudo tee -a /etc/apt/sources.list
        echo "Update the list of available packages"
        sudo apt-get update
        echo "Ensure that the Gateway pack is ready to install"
        sudo apt-cache search scaleft
        echo "Install the ASA Gateway"
        sudo apt-get install scaleft-gateway
	echo "Installing asciinema"
	sudo apt-add-repository ppa:zanchey/asciinema
	sudo apt-get update
	sudo apt-get install asciinema
fi
#Check for already enrolled
sudo ls /var/lib/sft-gatewayd/config/gw.dat > /dev/null 2>&1
if [ $? -eq 0 ]
then
	echo "This gateway is already assigned to a team."
	exit 1
fi
sleep 2
if [ ! -d /var/lib/sft-gatewayd ]
then
        echo "ERROR: Gateway installation failed"
        echo "Wait a few minutes and try again"
        exit 1
fi
clear
echo "ASA Gateway installed"
echo " "
echo "Paste the setup token here and press ENTER"
read et
echo "$et" | grep sft-gw > /dev/null
if [ $? -ne 0 ]
then
	echo "ERROR: Invalid enrollment token"
	exit 1
fi
echo "$et" |  cut -f3 -d\. | base64 -d | grep scaleft > /dev/null
if [ $? -eq 0 ]
then
	echo "Creating setup token file in /var/lib/sft-gatewayd"
	echo "$et" | sudo tee /var/lib/sft-gatewayd/setup.token
	echo "$et" > setup.token
else
	echo "ERROR: Invalid setup token"
fi
