#!/bin/bash
#Check for already running
ps -ef | grep -v grep | grep sftd > /dev/null
if [ $? -eq 0 ]
then
	echo "ASA server agent already running"
else
        echo "Adding the Advanced Server Access repository key"
        curl -fsSL https://dist.scaleft.com/GPG-KEY-OktaPAM-2023 | gpg --dearmor | sudo tee /usr/share/keyrings/oktapam-2023-archive-keyring.gpg > /dev/null
        echo "Create a package resource list entry"
        echo "deb [signed-by=/usr/share/keyrings/oktapam-2023-archive-keyring.gpg] https://dist.scaleft.com/repos/deb focal okta" | sudo tee -a /etc/apt/sources.list
        echo "Update the list of available packages"
        sudo apt-get update
        echo "Confirm that Server Tools package is now ready to install"
        sudo apt-cache search scaleft
        echo "Install the Advanced Server Access server tools"
        sudo apt-get install scaleft-server-tools
fi
#Check for already enrolled
sudo ls /var/lib/sftd/device.token > /dev/null 2>&1
if [ $? -eq 0 ]
then
	echo "This server is already enrolled in a project"
	exit 1
fi
sleep 2
if [ ! -d /var/lib/sftd ]
then
        echo "ERROR: Agent installation failed"
        echo "Wait a few minutes and try again"
        exit 1
fi
clear
echo "ASA Server Agent installed"
echo " "
echo "Type in an optional Canonical Name and press ENTER"
read cn
if [ ! -z "$cn" ]
then
	sudo mkdir -p /etc/sft
	echo "CanonicalName: $cn" | sudo tee /etc/sft/sftd.yaml
	echo "Created /etc/sft/sftd.yaml"
	echo " "
fi
echo "Paste the enrollment token here and press ENTER"
read et
echo "$et" | base64 -d  > /dev/null
if [ $? -ne 0 ]
then
	echo "ERROR: Invalid enrollment token"
	exit 1
fi
echo "$et" | base64 -d | grep scaleft > /dev/null
if [ $? -eq 0 ]
then
	echo "Creating enrollment.token file in /var/lib/sftd"
	echo "$et" | sudo tee /var/lib/sftd/enrollment.token
	echo "$et" > enrollment.token
else
	echo "ERROR: Invalid enrollment token"
fi
